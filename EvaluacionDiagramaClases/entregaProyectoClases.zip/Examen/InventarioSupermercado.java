import java.util.Scanner;
                                   //Espacios en blancooo
public class InventarioSupermercado {

    // Constante solicitada por la HU (número fijo de productos)
    private static final int MAX_PRODUCTOS = 5;

    // --- Punto de entrada ---
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] productos = new String[MAX_PRODUCTOS]; // vector de nombres
        int[] cantidades = new int[MAX_PRODUCTOS];      // vector de existencias

        // 1) Registro inicial (con validación de no-negativos)
        registrarInicial(sc, productos, cantidades);

        // 2) Menú principal (se repite después de cada acción)
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero(sc, "Seleccione una opción [1-5]: ", 1, 5);

            switch (opcion) {
                case 1 -> mostrarInventario(productos, cantidades);             // total con acumulador
                case 2 -> buscarProducto(sc, productos, cantidades);            // búsqueda por nombre
                case 3 -> actualizarInventario(sc, productos, cantidades);      // aumentar/disminuir con validaciones
                case 4 -> generarAlertas(productos, cantidades);                 // alertas < 10
                case 5 -> System.out.println("Saliendo del sistema de inventario...");
            }
        } while (opcion != 5);

        sc.close();
    }
                      //--------------------------------------------------------------------------
                     //registro inicial de los 5 puntos
                    //------------------------------------------------------------------------
    private static void registrarInicial(Scanner sc, String[] productos, int[] cantidades) {
        System.out.println("=== Registro inicial de productos (MAX = " + MAX_PRODUCTOS + ") ===");
        for (int i = 0; i < MAX_PRODUCTOS; i++) {
            String nombre = leerLineaNoVacia(sc, "Nombre del producto " + (i + 1) + ": ");
            int cantidad = leerEntero(sc, "Cantidad inicial para \"" + nombre + "\": ", 0, null); // no negativos
            productos[i] = nombre;
            cantidades[i] = cantidad;
        }
    }
                //--------------------------Menu en consola------------------------------
    private static void mostrarMenu() {
        System.out.println("\n===== MENU INVENTARIO SUPERMERCADO =====");
        System.out.println("1. Mostrar todos los productos y sus existencias");
        System.out.println("2. Buscar un producto por nombre y ver su cantidad");
        System.out.println("3. Actualizar inventario (aumentar o disminuir stock)");
        System.out.println("4. Generar alerta de productos con cantidad menor a 10");
        System.out.println("5. Salir");
    }
                               // --------------------------:V-------------------------------
                              // Opción 1: Mostrar inventario + variable acumuladora total
                             // ---------------------------------------------------------
    private static void mostrarInventario(String[] productos, int[] cantidades) {
        System.out.println("\n=== Inventario actual ===");
        int total = 0; // acumulador solicitado en la HU
        for (int i = 0; i < MAX_PRODUCTOS; i++) {
            System.out.printf("- %s: %d unidades%n", productos[i], cantidades[i]);
            total += cantidades[i];
        }
        System.out.println("Total de productos en inventario: " + total);
    }

                        // ------------------Fiuer7kp-------------------------
                       // Opción 2: Buscar producto por nombre
                      // -------------------------------------------
    private static void buscarProducto(Scanner sc, String[] productos, int[] cantidades) {
        String nombre = leerLineaNoVacia(sc, "Ingrese el nombre a buscar: ");
        int idx = buscarIndiceProducto(productos, nombre);
        if (idx >= 0) {
            System.out.printf("Producto encontrado: %s -> %d unidades%n", productos[idx], cantidades[idx]);
        } else {
            System.out.println("El producto \"" + nombre + "\" no existe en el inventario.");
        }
    }

                          // ----------------------xD-----------------------------------
                         // Opción 3: Actualizar inventario
                        // ---------------------------------------------------------
    private static void actualizarInventario(Scanner sc, String[] productos, int[] cantidades) {
        String nombre = leerLineaNoVacia(sc, "Producto a actualizar: ");
        int idx = buscarIndiceProducto(productos, nombre);

        if (idx < 0) {
            System.out.println("No existe un producto con ese nombre.");
            return;
        }

        System.out.println("Acción: 1) Aumentar  2) Disminuir");
        int accion = leerEntero(sc, "Seleccione 1 o 2: ", 1, 2);
        int delta = leerEntero(sc, "Cantidad a " + (accion == 1 ? "aumentar" : "disminuir") + ": ", 0, null);

        if (accion == 1) {
            // Aumentar
            cantidades[idx] += delta;
        } else {
            // Disminuir con validación de no-negativo
            if (cantidades[idx] - delta < 0) {
                System.out.println("Operación inválida: el stock no puede quedar negativo.");
                return;
            }
            cantidades[idx] -= delta;
        }

        System.out.printf("Actualizado: %s ahora tiene %d unidades.%n", productos[idx], cantidades[idx]);
    }

                       // ----------------------------------------------
                      // Opción 4: Alertas de baja existencia (< 10)
                     // ----------------------------------------------
    private static void generarAlertas(String[] productos, int[] cantidades) {
        System.out.println("\n=== Alertas de baja existencia (< 10) ===");
        boolean hayAlertas = false;
        for (int i = 0; i < MAX_PRODUCTOS; i++) {
            if (cantidades[i] < 10) {
                System.out.printf("ALERTA -> %s: %d unidades%n", productos[i], cantidades[i]);
                hayAlertas = true;
            }
        }
        if (!hayAlertas) System.out.println("No hay productos con baja existencia.");
    }

                     // ----------------------------------------------
                    // Utilidades (entradas robustas en consola)
                   // ----------------------------------------------
    private static int leerEntero(Scanner sc, String prompt, int min, Integer maxNullable) {
        Integer max = maxNullable; // para legibilidad
        while (true) {
            System.out.print(prompt);
            if (sc.hasNextInt()) {
                int n = sc.nextInt();
                sc.nextLine(); // limpia fin de línea
                if (n < min) {
                    System.out.println("Valor inválido: debe ser >= " + min + ".");
                    continue;
                }
                if (max != null && n > max) {
                    System.out.println("Valor inválido: debe ser <= " + max + ".");
                    continue;
                }
                return n;
            } else {
                System.out.println("Entrada no válida. Ingrese un número entero.");
                sc.nextLine();
            }
        }
    }

    private static String leerLineaNoVacia(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String linea = sc.nextLine().trim();
            if (!linea.isEmpty()) return linea;
            System.out.println("El texto no puede estar vacío. Intente de nuevo.");
        }
    }

    private static int buscarIndiceProducto(String[] productos, String nombre) {
        for (int i = 0; i < MAX_PRODUCTOS; i++) {
            if (productos[i].equalsIgnoreCase(nombre)) return i;
        }
        return -1;
    }
}
                                    //fin del susto <3 
